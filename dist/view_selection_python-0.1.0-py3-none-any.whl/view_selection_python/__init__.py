"""Tell python this directory is a package."""
from .main import run
