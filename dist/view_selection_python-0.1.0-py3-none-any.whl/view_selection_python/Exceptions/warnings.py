"""Warnings for CwdChecker."""

PROFILE_PATH_NOT_SET_WARNING = (
    "The profile path has not been recognized correctly. This is either due to "
    "necessary checks on the environment failing, or not being performed.\n"
    "Make sure that the do_all_checks() function runs without raising any errors, "
    "this will ensure that we obtain the correct file path."
)
